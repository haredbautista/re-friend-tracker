<script>
  let artists = $state([
    {
      _id: "62863381f8470b9fd1b0995f",
      name: "Daft Punk",
      origin: "France",
    },
    {
      _id: "6286354bf8470b9fd1b09965",
      name: "Chilly Gonzalez",
      origin: "Canada",
    },
    {
      _id: "646b9a2ac15e6199b1ec0b40",
      name: "Justin Bieber",
      origin: "Canada",
    },
  ]);
</script>

<h1>List of all Artists</h1>
<a href="/artists/create">+ Add Artist</a>
<table class="table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Origin</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    {#each artists as artist}
      <tr>
        <td>
          <a href={"/artists/" + artist._id}>
            {artist._id}
          </a>
        </td>
        <td>
          {artist.name}
        </td>
        <td>
          {artist.origin}
        </td>
        <td>
          <form>
            <button class="btn btn-danger">X</button>
          </form>
        </td>
      </tr>
    {/each}
  </tbody>
</table>
